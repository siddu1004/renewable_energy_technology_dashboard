@echo off
title HelioTrack Solar MPPT Launcher
setlocal enabledelayedexpansion

:: Project root directory
set "PROJECT_DIR=%~dp0"
cd /d "%PROJECT_DIR%"

echo ========================================================
echo   HELIOTRACK SOLAR MPPT DASHBOARD LAUNCHER
echo ========================================================
echo Checking server status on port 3000...

:: Check if port 3000 is already active
netstat -ano | findstr /R /C:":3000 .*LISTENING" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Dashboard server is already running!
    goto OPEN_BROWSER
)

echo [STARTING] Dashboard server is offline. Starting server...
:: Start npm run dev in a new minimized background window so it stays alive
start "HelioTrack Dashboard Server" /min cmd /c "cd /d "%PROJECT_DIR%" && npm run dev"

echo Waiting for server to initialize on http://localhost:3000...
set /a retries=0

:WAIT_LOOP
timeout /t 1 /nobreak >nul
set /a retries+=1

netstat -ano | findstr /R /C:":3000 .*LISTENING" >nul 2>&1
if %errorlevel% equ 0 (
    echo [READY] Server is up and listening on port 3000!
    goto OPEN_BROWSER
)

if %retries% geq 20 (
    echo [NOTE] Server is still compiling, opening browser now...
    goto OPEN_BROWSER
)

goto WAIT_LOOP

:OPEN_BROWSER
echo Opening http://localhost:3000 in your browser...
start http://localhost:3000
timeout /t 2 /nobreak >nul
exit /b 0
